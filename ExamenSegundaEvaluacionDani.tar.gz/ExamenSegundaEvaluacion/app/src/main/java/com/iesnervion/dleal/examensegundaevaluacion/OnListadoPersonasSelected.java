package com.iesnervion.dleal.examensegundaevaluacion;

/**
 * Created by dleal on 22/02/17.
 */

public interface OnListadoPersonasSelected {
    public void OnListadoPersonasSelected(int position);
}
