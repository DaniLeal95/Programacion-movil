package com.iesnervion.dleal.examenprimeraevaluacion;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import com.iesnervion.dleal.examenprimeraevaluacion.datos.ListadoJugadores;
import com.iesnervion.dleal.examenprimeraevaluacion.model.Jugador;

import java.util.List;
import java.util.Vector;

public class MainActivity extends ListActivity implements View.OnClickListener {

    private ListadoJugadores lista=new ListadoJugadores();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);


            Intent i= getIntent();
            Bundle bundle=i.getExtras();
        if(bundle !=null){
            Jugador j= bundle.getParcelable("Jugador");
            this.lista.setJugadores(j);
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(this);







        //Le añadimos adaptador a nuestra lista

        Vector<Jugador> jugadores = lista.getJugadores();
        setListAdapter(new MiArrayAdapter(this,R.layout.filajugador,jugadores));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

  /*  @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        //Recibimos el resultado
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode==1)
        {

            Bundle bundle= data.getExtras();


            Jugador j =bundle.getParcelable("Jugador");

            this.lista.setJugadores(j);
        }
    }*/

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.fab:
                Intent intent = new Intent(this, CreaJugador.class);
                startActivity(intent);
            break;

        }
    }
}
