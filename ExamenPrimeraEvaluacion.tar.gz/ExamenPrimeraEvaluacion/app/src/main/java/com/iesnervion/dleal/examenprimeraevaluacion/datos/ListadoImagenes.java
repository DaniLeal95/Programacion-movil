package com.iesnervion.dleal.examenprimeraevaluacion.datos;

import com.iesnervion.dleal.examenprimeraevaluacion.R;
import com.iesnervion.dleal.examenprimeraevaluacion.model.Imagen;

import java.util.Vector;

/**
 * Created by dleal on 7/12/16.
 */

public class ListadoImagenes {

    private Vector<Imagen> imagenes ;

    public ListadoImagenes() {
        this.imagenes = new Vector<>(0,1);

        imagenes.add(new Imagen(R.drawable.jugador00,false));
        imagenes.add(new Imagen(R.drawable.jugador01,false));
        imagenes.add(new Imagen(R.drawable.jugador02,false));
        imagenes.add(new Imagen(R.drawable.jugador03,false));
        imagenes.add(new Imagen(R.drawable.jugador04,false));
        imagenes.add(new Imagen(R.drawable.jugador05,false));
        imagenes.add(new Imagen(R.drawable.jugador06,false));
        imagenes.add(new Imagen(R.drawable.jugador07,false));
        imagenes.add(new Imagen(R.drawable.jugador08,false));
        imagenes.add(new Imagen(R.drawable.jugador09,false));
        imagenes.add(new Imagen(R.drawable.jugador10,false));
        imagenes.add(new Imagen(R.drawable.jugador11,false));
        imagenes.add(new Imagen(R.drawable.jugador12,false));
        imagenes.add(new Imagen(R.drawable.jugador13,false));
        imagenes.add(new Imagen(R.drawable.jugador14,false));
        imagenes.add(new Imagen(R.drawable.jugador15,false));
        imagenes.add(new Imagen(R.drawable.jugador16,false));
        imagenes.add(new Imagen(R.drawable.jugador17,false));
        imagenes.add(new Imagen(R.drawable.jugador18,false));
        imagenes.add(new Imagen(R.drawable.jugador19,false));
        imagenes.add(new Imagen(R.drawable.jugador20,false));
        imagenes.add(new Imagen(R.drawable.jugador21,false));
        imagenes.add(new Imagen(R.drawable.jugador22,false));
        imagenes.add(new Imagen(R.drawable.jugador23,false));


    }

    public Vector<Imagen> getImagenes() {
        return imagenes;
    }

    public void elimarimagen(int imagen){
        for(int i = 0;i<this.imagenes.size();i++){
            if(this.imagenes.elementAt(i).getImg()==imagen){
                imagenes.elementAt(i).setEscogido(true);
            }
        }
    }
}
