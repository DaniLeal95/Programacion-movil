package com.iesnervion.dleal.examenprimeraevaluacion;

import android.widget.ImageView;

/**
 * Created by dleal on 7/12/16.
 */

public class ViewHolderImagen {
    private ImageView imagen;

    public ViewHolderImagen(ImageView imagen) {
        this.imagen = imagen;
    }

    public ImageView getImagen() {
        return imagen;
    }
}
