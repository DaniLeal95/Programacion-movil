package com.iesnervion.dleal.examenprimeraevaluacion.datos;

import com.iesnervion.dleal.examenprimeraevaluacion.model.Jugador;

import java.util.Vector;

/**
 * Created by dleal on 7/12/16.
 */

public class ListadoJugadores {

    private Vector<Jugador> jugadores;
    private int numjugadores;

    public ListadoJugadores() {
        this.jugadores = new Vector<>(0,1);
        this.numjugadores = 0;
    }

    public Vector<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(Jugador j) {
        boolean juginsertado=false;

        //Esto es por si borran algun jugador, pueda meter otro en su lugar
        for(int i=0;i<jugadores.size();i++) {
            if(jugadores.elementAt(i)==null) {
                this.jugadores.add(i,j);
                juginsertado=true;
                numjugadores++;
            }
        }
        if(juginsertado==false && numjugadores < 10){
            jugadores.add(j);
            numjugadores++;
        }
    }
    public void eliminarJugador(Jugador j){
        for(int i=0;i<this.jugadores.size();i++){
            if(this.jugadores.elementAt(i).getNombre().equals(j.getNombre()) && (this.jugadores.elementAt(i).getAltura()==j.getAltura())){
                jugadores.removeElementAt(i);
                numjugadores--;
            }
        }
    }
}
